
function endpoint(pcs){
const { writeFile } = require('fs');
const fs = require('fs')
const { readFileSync } = require('fs');
let data = pcs

//const first = {"FeeConfigurationSpec" : "LNPY1221 NGN * *(*) : APPLY PERC 1.4\nLNPY1222 NGN INTL CREDIT-CARD(VISA) : APPLY PERC 5.0\nLNPY1223 NGN LOCL CREDIT-CARD(*) : APPLY FLAT_PERC 50:1.4\nLNPY1224 NGN * BANK-ACCOUNT(*) : APPLY FLAT 100\nLNPY1225 NGN * USSD(MTN) : APPLY PERC 0.55"}
let fcs1 = data["FeeConfigurationSpec"]
let fcs = fcs1.split("\n")


const dict = {
    fee_id: "", 
    fee_currency: "",
    fee_locale: "",
    fee_entity: "",
    column: "",
    functionn: "",
    fee_type: "",
    fee_value: []
    }

const dict1 = {
    fee_currency: ["NGN", "USD"],
    fee_locale: ["INTL","LOCL", "*"],
    fee_entity2:  ["CREDIT-CARD", "USSD", "DEBIT-CARD", "WALLET-ID", "BANK-ACCOUNT", "*"],
    fee_type: ["PERC", "FLAT", "FLAT_PERC"]
    }


function seperate(fcs,dict){
    fcs = fcs.split(" ");
    let y = Object.keys(dict)
    let lst = Array.from(Array(y.length).keys())
    
    for (let x in lst){
        dict[y[x]] = fcs[x];
    }
    return dict;
}


seperate(fcs[0],dict)

function check(fcs){
    let error = ""
    let count = 0
    for (let x in fcs){
        let checking = seperate(fcs[x], dict)
        checking['fee_entity2'] = checking['fee_entity'].split("(")[0]
        var letters = /^[0-9a-zA-Z]+$/;
        if (checking['fee_id'].length === 8 && checking['fee_id'].match(letters)){
            count += 1;}
        else{
            error += "Something wrong with fee_entity\n"
        }
        for (let i in dict1){
            if (dict1[i].includes(checking[i])){
                count ++
            }
            else{
            error += `Something wrong with ${i}\n`
        }
        }
        let fee_value2 = checking['fee_value'].split(":")
        if (fee_value2.length > 1){
            for(let i in fee_value2){
                if ("" + Number(fee_value2[i]) === "NaN"){
                    count--
                    error += `Something wrong with fee value\n`

                }
            }
        }
        else{
            if ( "" + Number(fee_value2[0]) === "NaN"){
                count --
                error += `Something wrong with fee value\n`
            }
        }
        }
    
    
    if (count === fcs.length * 5){
        let num = 1; 
        let dct = {}
        for (let x in fcs){
            dct[num] = fcs[x];
            num ++}
       writeFile("./file.json", JSON.stringify(dct, null, 2), (error) => {
            if (error) {
                console.log('An error has occurred ', error);
                return;
            }
            console.log('Data written successfully to disk');
            });
            
        
        return 'HTTP 200 OK \n {\n    "status": "ok"\n }'
    }
    else{
        return`HTTP 500 ERROR \n {\n    "status": ${error}\n }`
    }
}
let message = check(fcs)
return message
}

//endpoint({"FeeConfigurationSpec" : "LNPY1221 NGN * *(*) : APPLY PERC 1.4\nLNPY1222 NGN INTL CREDIT-CARD(VISA) : APPLY PERC 5.0\nLNPY1223 NGN LOCL CREDIT-CARD(*) : APPLY FLAT_PERC 50:1.4\nLNPY1224 NGN * BANK-ACCOUNT(*) : APPLY FLAT 100\nLNPY1225 NGN * USSD(MTN) : APPLY PERC 0.55"})
module.exports.endpoint = endpoint