function computation(pcs){
    'use strict';
    const { readFileSync } = require('fs');
    let data = readFileSync('./file.json');
    data = JSON.parse(data);
    for (let [ key, value ] of Object.entries(data)) {
        // do something with `key` and `value`
        data[key] = value.split(" ");
    }
    let message = ""
    let data1 = pcs
    let lst = [data1["Amount"],data1["Currency"], data1["CurrencyCountry"], data1["PaymentEntity"]["Country"] ,data1["PaymentEntity"]["Brand"], data1["PaymentEntity"]["Type"], data1["PaymentEntity"]["Issuer"]]
    if (lst[1] !== "NGN"){
        message += 'HTTP ANYTHING OTHER THAN 200 ERROR\n{\n  "Error": "No fee configuration for USD transactions."  \n}'}
    else{
        if (lst[2] === lst[3]){
            lst.push("LOCL")
        }
        else lst.push("INTL")
        let dict = {};
        let count = 0;
        for (let x in data){
            let pcs = data[x][3].split("(")[1]
            pcs = pcs.slice(0, pcs.length - 1);
            
            let pcs1 = data[x][3].split("(")[0]
            pcs1 = pcs1.slice(0, pcs1.length);
           
            
            
            if(data[x][2] === lst[7]){count += 2}
            else if(data[x][2] === "*"){count++}
            else count --
            
            if(pcs1 === lst[5]){count += 2}
            else if(pcs1 === "*"){count++}
            else count --

            if(pcs === lst[4] || pcs === lst[6] ){count += 2}
            else if(pcs === "*"){count++}
            else count --
        
            dict[data[x][0]] = count;
            count = 0
           
        }
        let max = Math.max.apply(null,Object.values(dict));
        let max2 = Object.keys(dict)[Object.values(dict).indexOf(max)]
        message+= `HTTP 200 OK \n{\n  "AppliedFeeID": ${max2},`
        let keyy
        for (let [ key, value ] of Object.entries(data)) {
            if (value.includes(max2)){
                keyy = key;
            }

        }
        let value = data[keyy]
        let fee = value[value.length - 1]
        let rate = value[value.length - 2]
        
        if (rate === "FLAT"){
            fee = Number(fee)
            fee = Math.round(fee)
            message+= `\n  "AppliedFeeValue": ${fee},`
        }
        else if (rate === "PERC"){
            fee = (Number(fee)/100) * lst[0]
            fee = Math.round(fee)
            message+= `\n  "AppliedFeeValue": ${fee},`
        }
        else if (rate === "FLAT_PERC"){
            fee = fee.split(":")
            fee = Number(fee[0]) + ((Number(fee[1])/100) * lst[0])
            fee = Math.round(fee)
            message+= `\n  "AppliedFeeValue": ${fee},`
        }
        else {
            fee = 0
            message+= `\n  "AppliedFeeValue": N/A,`
        }
        
        let amount = 0
        if (data1["Customer"]["BearsFee"] === false){
            amount = lst[0]
            message += `\n  "ChargeAmount": ${amount}`

        }
        else if (data1["Customer"]["BearsFee"] === true){
            amount = lst[0] + fee
            message += `\n  "ChargeAmount": ${amount},`
        }
        else {
            amount = lst[0]
            message+= `\n  "ChargeAmount": ${amount} (BearsFee is invalid, so charge amount is defaulting to the transaction amount)`
        }
        
        let settle = amount - fee
        message += `\n  "SettlementAmount": ${settle}\n}`
        
    
        
    }
    return message
}


module.exports.computation = computation;