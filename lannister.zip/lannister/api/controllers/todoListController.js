

const {endpoint} = require('./endpoint');
const {computation} = require("./computation.js")
var mongoose = require('mongoose'),
  Task = mongoose.model('lannister');

exports.list_all_tasks = function(req, res) {
  Task.find({}, function(err, task) {
    if (err)
      res.send(err);
    res.json(task);
  });
};


exports.endpoint = function(req, res) {
  let pcs = JSON.parse(JSON.stringify(req.body))
  var new_task = new Task(req.body);
  new_task.save(function(err, task) {
    if (err)
      res.send(err);
    pcs = JSON.parse(pcs["Pcs"])
    let messag = endpoint(pcs);
    res.status(200).json({message: messag});
  });
};

exports.computation = function(req, res) {
    let pld = JSON.parse(JSON.stringify(req.body))
    var new_task = new Task(req.body);
    new_task.save(function(err, task) {
      if (err)
        res.send(err);
      pld = JSON.parse(pld["Payload"])
      let messag = computation(pld);
      res.status(200).json({message: messag});
      
    });
  };





