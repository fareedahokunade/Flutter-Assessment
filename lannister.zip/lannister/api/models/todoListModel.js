'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var TaskSchema = new Schema({
  Pcs: {
    type: Array,
    required: 'Kindly enter the pcs'
  },
  Payload: {
    type: Array,
    required: 'Kindly enter the payload'
  },
  status: {
    type: [{
      type: String,
      enum: ['pending', 'ongoing', 'completed']
    }],
    default: ['pending']
  }
});

module.exports = mongoose.model('lannister', TaskSchema);