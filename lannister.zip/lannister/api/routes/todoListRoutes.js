'use strict';
module.exports = function(app) {
  var todoList = require('../controllers/todoListController');

  // todoList Routes
  app.route('/lannister')
    .get(todoList.list_all_tasks)
    

  app.route('/lannister/endpoint')
    .post(todoList.endpoint)

  app.route('/lannister/computation')
    .post(todoList.computation)

};
